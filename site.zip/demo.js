(function(){
  var P='/stepsecure', QMAP=null, inApp=location.pathname.indexOf(P+'/app')===0;
  fetch(P+'/qmap.json').then(function(r){return r.json()}).then(function(j){QMAP=j}).catch(function(){QMAP={}});
  var t;function toast(msg){var el=document.querySelector('.demo-toast');if(!el){el=document.createElement('div');el.className='demo-toast';el.setAttribute('role','status');document.body.appendChild(el);}el.textContent=msg;el.classList.add('is-on');clearTimeout(t);t=setTimeout(function(){el.classList.remove('is-on')},3500);}
  function go(url){var clean=url.replace(/&amp;/g,'&');if(QMAP&&QMAP[clean]){location.href=QMAP[clean];return;}var base=clean.split('?')[0];location.href=base.replace(/\/?$/,'/');}
  document.addEventListener('submit',function(e){
    var f=e.target;if(!(f instanceof HTMLFormElement))return;var m=(f.getAttribute('method')||'get').toLowerCase();if(m==='dialog')return;
    e.preventDefault();e.stopImmediatePropagation();
    var a=new URL(f.action,location.href),path=a.pathname;
    if(m==='get'){var q=new URLSearchParams(new FormData(f));var s=[];q.forEach(function(v,k){if(v!=='')s.push(encodeURIComponent(k)+'='+encodeURIComponent(v))});go(path+(s.length?'?'+s.join('&'):''));return;}
    if(/\/entrar\/?$/.test(path)){location.href=P+'/app/painel/';return;}
    if(/\/sair\/?$/.test(path)){location.href=P+'/entrar/';return;}
    if(/\/relatorios\/exportar\/?$/.test(path)){var fd=new FormData(f),rel=new URLSearchParams(location.search).get('relatorio')||fd.get('relatorio')||'atividades';var sel=document.getElementById('rf-relatorio');if(sel&&sel.value)rel=sel.value;location.href=P+'/app/relatorios/'+rel+'.'+(fd.get('formato')||'pdf');return;}
    if(/\/contato\/?$/.test(path)){toast('Demonstração: no site real, esta mensagem seria enviada para a equipe.');return;}
    toast('Versão de demonstração: esta ação funciona no sistema real, mas aqui nada é salvo.');
  },true);
})();
