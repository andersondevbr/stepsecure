(function () {
  'use strict';
  document.documentElement.classList.add('js');

  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.querySelector('.sr-only').textContent = open ? 'Fechar menu' : 'Abrir menu';
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.querySelector('.sr-only').textContent = 'Abrir menu';
        toggle.focus();
      }
    });
  }

  document.querySelectorAll('[data-count]').forEach(function (el) {
    var max = Number(el.getAttribute('data-count'));
    var out = document.createElement('p');
    out.className = 'counter';
    out.setAttribute('aria-live', 'polite');
    el.insertAdjacentElement('afterend', out);
    var update = function () {
      out.textContent = el.value.length.toLocaleString('pt-BR') + ' de ' + max.toLocaleString('pt-BR') + ' caracteres';
      out.classList.toggle('is-over', el.value.length > max);
    };
    el.addEventListener('input', update);
    update();
  });

  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      var first = null;
      form.querySelectorAll('[required]').forEach(function (el) {
        var wrap = el.closest('.field');
        var msg = wrap && wrap.querySelector('.field__error');
        var invalid = !el.value.trim() || (el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(el.value.trim()));
        if (invalid) {
          if (!msg && wrap) {
            msg = document.createElement('p');
            msg.className = 'field__error';
            msg.id = el.id + '-err';
            wrap.appendChild(msg);
          }
          if (msg) msg.textContent = el.type === 'email' && el.value.trim() ? 'Informe um e-mail válido.' : 'Campo obrigatório.';
          el.setAttribute('aria-invalid', 'true');
          el.setAttribute('aria-describedby', ((el.getAttribute('aria-describedby') || '') + ' ' + el.id + '-err').trim());
          if (wrap) wrap.classList.add('has-error');
          first = first || el;
        } else if (wrap) {
          wrap.classList.remove('has-error');
          el.removeAttribute('aria-invalid');
          if (msg) msg.textContent = '';
        }
      });
      if (first) {
        e.preventDefault();
        e.stopImmediatePropagation();
        first.focus();
      }
    });
  });

  document.querySelectorAll('form[data-once]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      var btn = form.querySelector('button[type="submit"]');
      if (form.dataset.sent) { e.preventDefault(); return; }
      form.dataset.sent = '1';
      if (btn) {
        btn.disabled = true;
        btn.classList.add('is-busy');
      }
      setTimeout(function () {
        delete form.dataset.sent;
        if (btn) {
          btn.disabled = false;
          btn.classList.remove('is-busy');
        }
      }, 15000);
    });
  });

  var alertBox = document.querySelector('[data-focus]');
  if (alertBox) alertBox.focus();
})();
