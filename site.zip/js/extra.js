(function(){
  var P='/stepsecure', QMAP={};
  fetch(P+'/qmap.json').then(function(r){return r.json()}).then(function(j){QMAP=j}).catch(function(){});
  var t;function toast(msg){var el=document.querySelector('.ss-toast');if(!el){el=document.createElement('div');el.className='ss-toast';el.setAttribute('role','status');document.body.appendChild(el);}el.textContent=msg;el.classList.add('is-on');clearTimeout(t);t=setTimeout(function(){el.classList.remove('is-on')},3000);}
  function go(url){if(QMAP[url]){location.href=QMAP[url];return;}location.href=url.split('?')[0].replace(/\/?$/,'/');}
  document.addEventListener('submit',function(e){
    var f=e.target;if(!(f instanceof HTMLFormElement))return;var m=(f.getAttribute('method')||'get').toLowerCase();if(m==='dialog')return;
    e.preventDefault();e.stopImmediatePropagation();
    var path=new URL(f.action,location.href).pathname;
    if(m==='get'){var s=[];new FormData(f).forEach(function(v,k){if(v!=='')s.push(encodeURIComponent(k)+'='+encodeURIComponent(v))});go(path+(s.length?'?'+s.join('&'):''));return;}
    if(/\/entrar\/?$/.test(path)){var em=((f.querySelector('[name=email]')||{}).value||'').trim().toLowerCase();var U={'diego.santos@metalurgicahorizonte.com.br':'/u/colaborador','bruno.almeida@metalurgicahorizonte.com.br':'/u/supervisor'};location.href=P+(U[em]||'')+'/app/painel/';return;}
    if(/\/sair\/?$/.test(path)){location.href=P+'/entrar/';return;}
    if(/\/relatorios\/exportar\/?$/.test(path)){var fd=new FormData(f),rel=fd.get('relatorio')||'atividades';location.href=location.pathname.split('/app/')[0]+'/app/relatorios/'+rel+'.'+(fd.get('formato')||'pdf');return;}
    if(/\/contato\/?$/.test(path)){toast('Mensagem enviada. Retornaremos em breve.');f.reset();return;}
    if(/\/recuperar-senha\/?$/.test(path)){toast('Se o e-mail estiver cadastrado, você receberá as instruções.');return;}
    toast('Alterações salvas.');
  },true);
})();
