(function () {
  'use strict';
  document.documentElement.classList.add('js');
  var csrf = document.body.getAttribute('data-csrf');

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  var sidebar = $('#sidebar');
  var backdrop = $('.sidebar-backdrop');
  var opener = $('[data-nav-open]');
  function setNav(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('is-open', open);
    if (backdrop) backdrop.hidden = !open;
    if (opener) opener.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) { var first = $('a', sidebar); if (first) first.focus(); } else if (opener) opener.focus();
  }
  if (opener) opener.addEventListener('click', function () { setNav(true); });
  $$('[data-nav-close]').forEach(function (el) { el.addEventListener('click', function () { setNav(false); }); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && sidebar && sidebar.classList.contains('is-open')) setNav(false);
  });

  var toast = $('[data-toast]');
  if (toast) {
    var closeToast = function () { toast.remove(); };
    $('[data-toast-close]', toast).addEventListener('click', closeToast);
    if (!toast.classList.contains('toast--error')) setTimeout(closeToast, 7000);
  }

  var errorBox = $('[data-focus]');
  if (errorBox) errorBox.focus();

  $$('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { el.form.submit(); });
  });

  $$('form[data-once]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (form.dataset.sent) { e.preventDefault(); return; }
      form.dataset.sent = '1';
      var btn = e.submitter || $('button[type="submit"]', form);
      if (btn) {
        if (btn.name) {
          var h = document.createElement('input');
          h.type = 'hidden'; h.name = btn.name; h.value = btn.value;
          form.appendChild(h);
        }
        setTimeout(function () { btn.disabled = true; btn.classList.add('is-busy'); }, 0);
      }
    });
  });

  var dialog = $('#confirm-dialog');
  $$('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (form.dataset.confirmed || !dialog || typeof dialog.showModal !== 'function') return;
      e.preventDefault();
      e.stopImmediatePropagation();
      var trigger = document.activeElement;
      $('[data-confirm-text]', dialog).textContent = form.getAttribute('data-confirm');
      dialog.returnValue = '';
      dialog.showModal();
      dialog.addEventListener('close', function onClose() {
        dialog.removeEventListener('close', onClose);
        if (dialog.returnValue === 'ok') {
          form.dataset.confirmed = '1';
          if (form.requestSubmit) form.requestSubmit(trigger && trigger.form === form && trigger.type === 'submit' ? trigger : undefined); else form.submit();
        } else if (trigger) trigger.focus();
      });
    }, true);
  });

  var dirty = false;
  $$('form[data-dirty]').forEach(function (form) {
    form.addEventListener('input', function () { dirty = true; });
    form.addEventListener('change', function () { dirty = true; });
    form.addEventListener('submit', function () { dirty = false; });
  });
  window.addEventListener('beforeunload', function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });

  var source = $('[data-sector-source]');
  if (source) {
    var apply = function () {
      var sector = source.value;
      $$('select[data-filter-sector]').forEach(function (sel) {
        $$('option[data-sectors]', sel).forEach(function (opt) {
          var ok = !sector || opt.getAttribute('data-sectors').split(' ').indexOf(sector) >= 0;
          opt.hidden = !ok;
          opt.disabled = !ok;
          if (!ok && opt.selected) sel.value = '';
        });
      });
      $$('[data-filter-sector-list] [data-sectors]').forEach(function (label) {
        var ok = !sector || label.getAttribute('data-sectors') === sector;
        label.hidden = !ok;
        var box = $('input', label);
        if (!ok && box) box.checked = false;
      });
    };
    source.addEventListener('change', apply);
    apply();
  }

  $$('[data-count]').forEach(function (el) {
    var max = Number(el.getAttribute('data-count'));
    var out = document.createElement('p');
    out.className = 'counter';
    el.insertAdjacentElement('afterend', out);
    var update = function () {
      out.textContent = el.value.length.toLocaleString('pt-BR') + ' de ' + max.toLocaleString('pt-BR') + ' caracteres';
      out.classList.toggle('is-over', el.value.length > max);
    };
    el.addEventListener('input', update);
    update();
  });

  $$('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement.querySelector('input');
      input.select();
      var done = function () { btn.textContent = 'Copiado'; setTimeout(function () { btn.textContent = 'Copiar link'; }, 2500); };
      if (navigator.clipboard) navigator.clipboard.writeText(input.value).then(done, function () { document.execCommand('copy'); done(); });
      else { document.execCommand('copy'); done(); }
    });
  });
  $$('[data-select]').forEach(function (el) { el.addEventListener('focus', function () { el.select(); }); });

  $$('form[data-autosave]').forEach(function (form) {
    var status = $('[data-save-status]', form);
    var timer = null;
    var inflight = false;
    var pending = false;
    function setStatus(text, kind) {
      status.textContent = text;
      status.classList.toggle('is-error', kind === 'error');
      status.classList.toggle('is-ok', kind === 'ok');
    }
    function save() {
      if (inflight) { pending = true; return; }
      inflight = true;
      setStatus('Salvando…');
      var data = new URLSearchParams(new FormData(form));
      fetch(form.action, {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': csrf },
        body: data,
        credentials: 'same-origin'
      }).then(function (r) {
        if (r.status === 401) throw new Error('session');
        return r.json().then(function (body) { if (!r.ok) throw new Error(body.message || 'fail'); return body; });
      }).then(function (body) {
        var errs = body.errors || {};
        $$('.cl-item .field__error[data-auto]').forEach(function (el) { el.remove(); });
        var keys = Object.keys(errs);
        keys.forEach(function (k) {
          var item = document.getElementById('item-' + k.slice(2));
          if (item) {
            var p = document.createElement('p');
            p.className = 'field__error'; p.setAttribute('data-auto', '1'); p.textContent = errs[k];
            item.appendChild(p);
          }
        });
        setStatus(keys.length ? 'Última gravação confirmada às ' + body.saved_label + '. ' + keys.length + ' resposta(s) com valor inválido não foram gravadas.' : 'Última gravação confirmada às ' + body.saved_label + '.', keys.length ? 'error' : 'ok');
      }).catch(function (err) {
        if (err.message === 'session') setStatus('Sua sessão expirou. Entre novamente; as respostas já gravadas foram preservadas.', 'error');
        else if (err.message && err.message !== 'fail' && err.message !== 'Failed to fetch') setStatus(err.message, 'error');
        else setStatus('Não foi possível confirmar a gravação. Verifique a conexão e tente novamente.', 'error');
      }).then(function () {
        inflight = false;
        if (pending) { pending = false; save(); }
      });
    }
    var fields = $$('[form="' + form.id + '"]');
    fields.forEach(function (el) {
      el.addEventListener('change', function () { clearTimeout(timer); timer = setTimeout(save, 400); });
      if (el.tagName === 'TEXTAREA' || el.type === 'text') el.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(save, 1500); });
    });
    form.addEventListener('submit', function (e) { e.preventDefault(); clearTimeout(timer); save(); });
  });

  $$('form[data-upload]').forEach(function (form) {
    var queue = $('.upload__queue', form);
    $$('input[data-file]', form).forEach(function (input) {
      input.addEventListener('change', function () {
        if (!input.files || !input.files[0]) return;
        send(input.files[0]);
        input.value = '';
      });
    });
    function send(file) {
      var li = document.createElement('li');
      var name = document.createElement('span');
      name.textContent = file.name;
      var cancel = document.createElement('button');
      cancel.type = 'button'; cancel.className = 'btn btn--ghost btn--sm'; cancel.textContent = 'Cancelar';
      var bar = document.createElement('progress');
      bar.max = 100; bar.value = 0;
      bar.setAttribute('aria-label', 'Progresso do envio de ' + file.name);
      li.appendChild(name); li.appendChild(cancel); li.appendChild(bar);
      queue.appendChild(li);

      var fd = new FormData();
      fd.append('_csrf', csrf);
      $$('select, input[type="text"]', form).forEach(function (el) { if (el.name) fd.append(el.name, el.value); });
      fd.append('file', file, file.name);
      var xhr = new XMLHttpRequest();
      xhr.open('POST', form.action);
      xhr.setRequestHeader('Accept', 'application/json');
      xhr.setRequestHeader('X-CSRF-Token', csrf);
      xhr.upload.addEventListener('progress', function (e) { if (e.lengthComputable) bar.value = Math.round((e.loaded / e.total) * 95); });
      function failed(msg) {
        bar.remove();
        cancel.remove();
        var err = document.createElement('span');
        err.className = 'is-error';
        err.textContent = msg;
        var retry = document.createElement('button');
        retry.type = 'button'; retry.className = 'btn btn--secondary btn--sm'; retry.textContent = 'Tentar novamente';
        retry.addEventListener('click', function () { li.remove(); send(file); });
        li.appendChild(err); li.appendChild(retry);
      }
      xhr.onload = function () {
        var body = {};
        try { body = JSON.parse(xhr.responseText); } catch (e) {                         }
        if (xhr.status === 201) {
          bar.value = 100;
          name.textContent = file.name + ' · enviado';
          cancel.remove();
          setTimeout(function () { window.location.reload(); }, 400);
        } else if (xhr.status === 401) failed('Sua sessão expirou. Entre novamente e repita o envio.');
        else failed((body.field_errors && body.field_errors.file) || body.message || 'Não foi possível confirmar o envio.');
      };
      xhr.onerror = function () { failed('Não foi possível confirmar o envio. Verifique a conexão e tente novamente.'); };
      xhr.onabort = function () { failed('Envio cancelado. Nada foi salvo.'); };
      cancel.addEventListener('click', function () { xhr.abort(); });
      xhr.send(fd);
    }
  });

  var poll = $('[data-poll]');
  if (poll) setTimeout(function () { window.location.reload(); }, Number(poll.getAttribute('data-poll')) * 1000);
})();
